    // First we trigger the form submit event
jQuery( document ).ready( function () {

    jQuery(document).ready(function($) {
        // Define as variáveis que vão receber os valores dos campos de email
        var email1 = "";
        var email2 = "";
      
        // Define o botão de envio como uma variável
        var submitButton = $('.wpcf7-submit');
        // Adiciona um listener de mudança para os campos de email
        $('input[type="email"]').on('change', function() {
          email1 = $('input[name="email"]').val();
          email2 = $('input[name="email-confirm"]').val();
      /*
          // Compare email values and enable/disable submit button
          if (email1 == email2) {
            submitButton.prop('disabled', false);
          } else {
            submitButton.prop('disabled', true); 
          }*/

          if (email1 == email2) {
            submitButton.prop('disabled', false);
            $('.email-mismatch').hide(); // Oculta a mensagem de erro, se ela já estiver sendo exibida
          } else {
            submitButton.prop('disabled', true);
            $('.email-mismatch').text('Os e-mails não coincidem.').show(); // Exibe a mensagem de erro
            console.log();
          }
          
         });
      });
});