=== Email Confirmation and Phone Validation Contact form 7 ===
Contributors: Escola Ninja WP
Donate link: https://escolaninjawp.com.br/
Tags: addon Contact Form 7, phone mask, email field confirmation
Requires at least: 6.2
Tested up to: 6.2
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

With this plugin you can add an email field to confirm the email in the contact form and in the phone it adds a mask in the phone field.
* [View Demo]()
* [Video Tutorials]()

== Installation ==

Upload the plugin to the wp-content/plugins folder on your server.
Activate the plugin in the "Plugins" section of the WordPress admin panel.
Have Contact Form 7 installed and configure the contact form 7 form as suggested.

== Utilização ==

Com este plugin você consegue adicionar um campo de email para confirmar o email no formulário de contato e no telefone ele adiciona uma máscara no campo do telefone.
Veja como deve ser o formulário, para o campo do email e confirmação de email:
[email* email class:email placeholder "Informe seu email"]
[email* confirmar-email class:email-confirm placeholder "Confirme seu email"]

Para o campo do telefone:
[tel* telefone class:telefone placeholder "Telefone"]

Access the page to see how an example of the Contact Form works:
https://mailcontactform7.saberparatodos.com.br/formulario-com-ddd-no-telefone/
== Changelog ==

1.2 - Atualizamos o plugin para que seja possível adicionar máscara no campo do telefone.
1.0 - A primeira versão liberada, foi apenas para confirmar campo do email.

== Support ==

If you have problems you will have support, only on questions related to the plugin.

== License ==

The version of this plugin is free.