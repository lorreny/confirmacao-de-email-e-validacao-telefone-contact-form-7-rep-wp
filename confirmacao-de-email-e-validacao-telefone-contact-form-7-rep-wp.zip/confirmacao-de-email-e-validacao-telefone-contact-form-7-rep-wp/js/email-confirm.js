jQuery( document ).ready( function () {
  jQuery(document).ready(function($) {
    // Define as variáveis que vão receber os valores dos campos de email
    var email1 = "";
    var email2 = "";
    
    // Define o botão de envio e a mensagem de erro como variáveis
    var submitButton = $('.wpcf7-submit');
    var errorMessage = $('<div class="error-message" style="background: red; padding: 10px 15px; color: #ffffff;">Os campos de email devem ser iguais</div>');
    
    // Adiciona a mensagem de erro ao formulário
    $('.wpcf7-form').append(errorMessage);
    
    // Esconde a mensagem de erro por padrão
    errorMessage.hide();
    
    // Adiciona um listener de mudança para os campos de email
    $('input[type="email"]').on('change', function() {
      email1 = $('.email').val();
      email2 = $('.email-confirm').val();
  
      // Compare email values and enable/disable submit button
      if (email1 == email2) {
        submitButton.prop('disabled', false);
        errorMessage.hide();
      } else {
        submitButton.prop('disabled', true); 
        errorMessage.show();
      }
    });
  });

jQuery(function($) {
  // Adicionar máscara para o campo de telefone
  $('.telefone').inputmask({ 
    mask: '(99) [9] 9999-9999',
    greedy: false,
    definitions: {
      '#': {
        validator: "[0-9]",
        cardinality: 1
      }
    }
  });

  // Adicionar validação para o número de telefone
  $('form.wpcf7-form').submit(function() {
    var telefone = $('.telefone').val().replace(/\D/g, '');
    if (telefone.length < 9) {
      alert('Por favor, insira um telefone válido.');
      return false;
    }
  });
});


});